# AQA GCSE Biology Exam Prep — Higher Tier

Your interactive revision app for AQA GCSE Biology 8461 (Higher).

## 📋 Files Included

- **index.html** — Main page (loads React from CDN)
- **bundle.js** — Your complete exam prep app
- **README.md** — This file

Keep all three files in the same folder.

---

## 🚀 Deploy to GitHub Pages (Free Public URL)

### Step 1: Create a GitHub Repository

1. Go to **github.com** (sign up if needed)
2. Click the **+** icon (top right) → **New repository**
3. **Repository name:** `exam-prep` (or any name you like)
4. **Make it PUBLIC** ✓
5. Click **Create repository**

### Step 2: Upload Your Files

1. In your new repo, click **Add file** → **Upload files**
2. Drag and drop (or select) all three files:
   - `index.html`
   - `bundle.js`
   - `README.md`
3. At the bottom, click **Commit changes**

### Step 3: Enable GitHub Pages

1. In your repo, go to **Settings** (top navigation)
2. Scroll down to **Pages** (left sidebar)
3. Under "Source", select:
   - Branch: `main`
   - Folder: `/(root)`
4. Click **Save**

GitHub will show you a message like:
> "Your site is live at `https://yourusername.github.io/exam-prep/`"

**That's your live URL.** It goes live in ~30 seconds.

---

## 💾 Local Testing (Before Uploading)

To test before uploading to GitHub:

1. Save all three files in a folder on your computer
2. Double-click `index.html`
3. Your app opens in your browser — fully functional, works offline

---

## 📱 Usage

- Click on any topic (Cell Biology, Organisation, etc.) to start
- Work through MCQ, short-answer, and 4/3-mark exam questions
- See model answers, mark schemes, and examiner tips
- Progress is saved in your browser's local storage
- Progress syncs across tabs, but resets if you clear browser data or switch browsers

---

## ⚙️ Customization

The app currently loads AQA Biology topics. To add more subjects (Chemistry, Physics, Maths, etc.), edit `bundle.js`:

1. Replace the `UNITS` and `LESSONS` arrays with your content
2. Follow the same structure (topic codes, question types, mark schemes)
3. Redeploy to GitHub (re-upload the file)

---

## 📞 Support

- **Link fails to load?** Check your internet — it loads React from a CDN
- **Progress lost?** Browser local storage is only per-device, per-browser
- **Questions not rendering?** Check browser console (F12) for errors

---

**Exam success! 🎓**
