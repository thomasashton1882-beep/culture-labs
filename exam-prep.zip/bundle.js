const React = window.React;
const { useState, useEffect, useRef } = React;

// ===== AQA GCSE Biology 8461 (Higher) — Paper 1 content bank =====
// Topic codes taken from the AQA 8461 specification.
const UNITS = [
  { id:'u1', code:'4.1', name:'Cell Biology',        blurb:'Structure, division, transport', hue:'var(--violet)' },
  { id:'u2', code:'4.2', name:'Organisation',        blurb:'Enzymes, circulation, plants',   hue:'var(--rose)' },
  { id:'u3', code:'4.3', name:'Infection & Response', blurb:'Pathogens, immunity, drugs',    hue:'var(--cyan)' },
  { id:'u4', code:'4.4', name:'Bioenergetics',       blurb:'Photosynthesis & respiration',   hue:'var(--lime)' },
  { id:'u5', code:'4.5', name:'Homeostasis & Response',        blurb:'Nerves, hormones, plants',      hue:'var(--amber)' },
  { id:'u6', code:'4.6', name:'Inheritance & Evolution',        blurb:'DNA, genetics, natural selection', hue:'var(--cyan)' },
  { id:'u7', code:'4.7', name:'Ecology',                        blurb:'Ecosystems, cycles, food',     hue:'var(--lime)' },
  { id:'u8', code:'RP',  name:'Required Practicals · Paper 1',   blurb:'RP1–6 · diagrams, methods, data', hue:'var(--rose)' },
  { id:'u9', code:'RP',  name:'Required Practicals · Paper 2',   blurb:'RP7–10 · sampling, tropisms, decay', hue:'var(--violet)' },
];

const LESSONS = [
{ id:'l1', unit:'u1', code:'4.1.1', title:'Cell structure & specialisation', qs:[
 {t:'mcq', q:'Which structure is found in a prokaryotic cell but NOT in a eukaryotic cell?', o:['Ribosomes','Plasmids','Cell membrane','Cytoplasm'], a:1,
  why:'Prokaryotes carry extra small rings of DNA called plasmids. Ribosomes, membrane and cytoplasm are in both.',
  tip:'Examiners want "single circular strand of DNA" + "plasmids" as the two DNA differences. Saying only "no nucleus" caps you at 1 mark.'},
 {t:'mcq', q:'A sperm cell has many mitochondria. This is because:', o:['It needs to store genetic material','It releases energy for swimming','It digests the egg membrane','It reduces its own mass'], a:1,
  why:'Mitochondria are the site of aerobic respiration, releasing energy for the tail to move.',
  tip:'Never write "mitochondria produce energy". AQA examiner reports flag this every year — energy is TRANSFERRED or RELEASED, never made.'},
 {t:'short', q:'Name the organelle that is the site of protein synthesis.', a:['ribosome','ribosomes'],
  why:'Ribosomes assemble amino acids into proteins.',
  tip:'One-word answers still need precision. "Ribosome" scores; "ribosomal RNA" does not.'},
 {t:'short', q:'Give the term for a cell becoming specialised for a particular function.', a:['differentiation','differentiate','cell differentiation'],
  why:'Differentiation is the process where a cell gains a new sub-set of sub-cellular structures.',
  tip:'Distinguish differentiation (gaining a function) from division (making more cells). Mixing them is a common lost mark.'},
 {t:'mcq', q:'Root hair cells have a large surface area mainly to:', o:['Support the plant','Increase water and mineral uptake','Store starch','Carry out photosynthesis'], a:1,
  why:'The long extension increases surface area for faster absorption of water (osmosis) and mineral ions (active transport).',
  tip:'Always name the transport process. "Absorbs more water" = 1 mark; "more water by osmosis, more mineral ions by active transport" = 2.'},
 {t:'short', q:'In plant cells, which structure is made of cellulose?', a:['cell wall','the cell wall'],
  why:'The cellulose cell wall strengthens the cell and resists bursting when turgid.',
  tip:'Bacteria also have a cell wall — but it is NOT cellulose. Watch that trap in comparison questions.'},
 {t:'exam', marks:4, q:'Describe two ways the structure of a prokaryotic cell differs from a eukaryotic cell, and explain one way a sperm cell is adapted to its function. (4 marks)',
  scheme:['Prokaryote genetic material is a single circular strand of DNA / not enclosed in a nucleus','Prokaryote has plasmids (eukaryote does not)','Sperm has a tail / flagellum to swim to the egg','Sperm has many mitochondria to release energy for swimming (or: acrosome with enzymes to digest the egg membrane; haploid nucleus)'],
  model:'A prokaryotic cell has no nucleus — its genetic material is a single circular strand of DNA free in the cytoplasm — and it also contains plasmids, which eukaryotic cells do not have. A sperm cell has many mitochondria, which release energy from respiration so the tail can move and the sperm can swim to the egg.',
  tip:'"Describe two ways... and explain one" is a structured command. Number your points mentally — write exactly 2 + 1. Padding with a third difference wastes time and earns nothing.'},
 {t:'exam', marks:3, q:'Explain why a muscle cell contains more mitochondria than a skin cell. (3 marks)',
  scheme:['Muscle cells contract / do more work','This requires more energy','Mitochondria are the site of aerobic respiration, which releases the energy'],
  model:'Muscle cells contract and so do far more work than skin cells. Contraction requires a large amount of energy. Mitochondria are the site of aerobic respiration, which releases energy from glucose, so more mitochondria mean more respiration and more energy released per second.',
  tip:'On "explain" questions build a causal chain: need → why → mechanism. Each arrow is usually worth a mark.'},
]},

{ id:'l2', unit:'u1', code:'4.1.1.5', title:'Microscopy & magnification', qs:[
 {t:'short', q:'Write the magnification equation (use the words image, real, magnification).', a:['magnification = image size / real size','magnification=image size/real size','magnification = size of image / size of real object','image size / real size'],
  why:'Magnification = size of image ÷ size of real object. Rearranged: real = image ÷ magnification.',
  tip:'Write the equation down BEFORE substituting. AQA awards a mark for a correct rearrangement even if the arithmetic then goes wrong.'},
 {t:'short', q:'A cell is 0.05 mm wide. Convert this to micrometres (µm). Give the number only.', a:['50','50 um','50µm','50 µm'],
  why:'1 mm = 1000 µm, so 0.05 × 1000 = 50 µm.',
  tip:'Unit conversion is the single biggest source of dropped marks in this topic. mm → µm is ×1000; µm → nm is ×1000.'},
 {t:'mcq', q:'An image of a cell is 40 mm wide at ×2000 magnification. What is the real width?', o:['0.02 mm','0.2 mm','2 mm','20 µm'], a:0,
  why:'Real = image ÷ magnification = 40 ÷ 2000 = 0.02 mm (which is 20 µm).',
  tip:'Both 0.02 mm and 20 µm are the same answer — but you must give the unit the question asks for or you lose the final mark.'},
 {t:'mcq', q:'The main advantage of an electron microscope over a light microscope is:', o:['It is cheaper','It has higher magnification AND higher resolving power','Specimens stay alive','It uses coloured light'], a:1,
  why:'Electron microscopes have both much greater magnification and much greater resolution, revealing sub-cellular structures like ribosomes.',
  tip:'You must say BOTH magnification and resolution. Saying only "it magnifies more" is a half-answer and scores 1 of 2.'},
 {t:'short', q:'Define resolution (resolving power) in one phrase.', a:['ability to distinguish between two points','ability to distinguish two separate points','the ability to distinguish between two points that are close together','distinguish between two close points'],
  why:'Resolution is the ability to distinguish between two points that are close together.',
  tip:'Avoid "how clear the image is" — examiner reports call this too vague for the mark.'},
 {t:'short', q:'Required practical: name the stain commonly used to make plant cell nuclei visible.', a:['iodine','iodine solution'],
  why:'Iodine solution stains plant cells; methylene blue is used for cheek (animal) cells.',
  tip:'Also know WHY you lower the coverslip at an angle — to avoid trapping air bubbles that obscure the cells.'},
 {t:'exam', marks:4, q:'A student measures a chloroplast on a drawing as 30 mm across. The drawing has a magnification of ×6000. Calculate the real diameter of the chloroplast in micrometres. Show your working. (4 marks)',
  scheme:['States real size = image size ÷ magnification','30 ÷ 6000 = 0.005 mm','Converts: 0.005 × 1000','Answer = 5 µm'],
  model:'Real size = image size ÷ magnification = 30 mm ÷ 6000 = 0.005 mm. Converting to micrometres: 0.005 × 1000 = 5 µm.',
  tip:'"Show your working" means the marks are IN the working. Even a wrong final answer keeps 3 of 4 marks if the method is laid out. Never just write the number.'},
 {t:'exam', marks:3, q:'Explain why sub-cellular structures such as ribosomes can be seen with an electron microscope but not a light microscope. (3 marks)',
  scheme:['Electron microscope has much higher resolution / resolving power','So it can distinguish between two very close points','Ribosomes are too small / below the resolution limit of a light microscope (also credit: much higher magnification)'],
  model:'An electron microscope has a much higher resolving power, so it can distinguish between two points that are extremely close together. Ribosomes are far too small to be resolved by a light microscope, so they appear as a blur or not at all, but the electron microscope also magnifies far more, making them visible.',
  tip:'Resolution is the marking point examiners are hunting for here. Lead with it, then support with magnification.'},
]},
];

function App() {
  const [currentPage, setCurrentPage] = useState('hub');
  const [sessionState, setSessionState] = useState(null);
  const [answered, setAnswered] = useState(new Map());
  const [progress, setProgress] = useState({});

  const handleStartSession = (unitId) => {
    const unit = UNITS.find(u => u.id === unitId);
    const lessons = LESSONS.filter(l => l.unit === unitId);
    setSessionState({ unitId, unit, lessons, currentLessonIdx: 0 });
    setCurrentPage('session');
  };

  const handleAnswerQuestion = (qIdx, correct) => {
    setAnswered(prev => new Map(prev).set(`${sessionState.unitId}-${sessionState.currentLessonIdx}-${qIdx}`, correct));
    setProgress(prev => ({
      ...prev,
      [sessionState.unitId]: {
        ...(prev[sessionState.unitId] || {}),
        answered: (prev[sessionState.unitId]?.answered || 0) + 1,
        correct: (prev[sessionState.unitId]?.correct || 0) + (correct ? 1 : 0),
      }
    }));
  };

  const renderHub = () => (
    <div style={styles.hub}>
      <div style={styles.header}>
        <div style={styles.brand}>📚 AQA Biology Revision</div>
        <div style={styles.subtitle}>Higher Tier GCSE 8461</div>
      </div>
      <div style={styles.unitsGrid}>
        {UNITS.map(unit => {
          const unitProgress = progress[unit.id] || {};
          return (
            <button
              key={unit.id}
              onClick={() => handleStartSession(unit.id)}
              style={{...styles.unitCard, borderColor: unit.hue}}
            >
              <div style={styles.unitCode}>{unit.code}</div>
              <div style={styles.unitName}>{unit.name}</div>
              <div style={styles.unitBlurb}>{unit.blurb}</div>
              {unitProgress.answered > 0 && (
                <div style={styles.unitProgress}>
                  {unitProgress.correct}/{unitProgress.answered} correct
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );

  const renderSession = () => {
    if (!sessionState) return null;
    const lesson = sessionState.lessons[sessionState.currentLessonIdx];
    const currentQ = lesson.qs[0];

    return (
      <div style={styles.session}>
        <button onClick={() => { setCurrentPage('hub'); setSessionState(null); }} style={styles.backBtn}>← Back</button>
        <div style={styles.sessionHeader}>
          <div>{sessionState.unit.name}</div>
          <div style={styles.lessonTitle}>{lesson.title}</div>
        </div>
        <div style={styles.qContainer}>
          <div style={styles.qtext}>{currentQ.q}</div>
          {currentQ.t === 'mcq' && (
            <div style={styles.options}>
              {currentQ.o.map((opt, i) => (
                <button
                  key={i}
                  onClick={() => handleAnswerQuestion(0, i === currentQ.a)}
                  style={{...styles.option, backgroundColor: i === currentQ.a ? '#4CAF50' : '#333'}}
                >
                  {opt}
                </button>
              ))}
            </div>
          )}
          {currentQ.t === 'short' && (
            <div style={styles.answerBox}>
              <div style={styles.answerLabel}>Model answer:</div>
              <div style={styles.answerText}>{currentQ.a[0]}</div>
            </div>
          )}
          {currentQ.t === 'exam' && (
            <div style={styles.examBox}>
              <div style={styles.examMarks}>({currentQ.marks} marks)</div>
              <div style={styles.schemeLabel}>Mark scheme:</div>
              <ul style={styles.schemeList}>
                {currentQ.scheme.map((point, i) => (
                  <li key={i}>{point}</li>
                ))}
              </ul>
              <div style={styles.modelLabel}>Model answer:</div>
              <div style={styles.modelText}>{currentQ.model}</div>
            </div>
          )}
          <div style={styles.tipBox}><strong>💡 Tip:</strong> {currentQ.tip}</div>
        </div>
      </div>
    );
  };

  return (
    <div style={styles.container}>
      <style>{`
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', system-ui, sans-serif; background: #0B0918; color: #F5F5F5; }
        * { --violet: #9D4EDD; --rose: #FF006E; --cyan: #00D9FF; --lime: #39FF14; --amber: #FFB703; }
      `}</style>
      {currentPage === 'hub' ? renderHub() : renderSession()}
    </div>
  );
}

const styles = {
  container: { maxWidth: '1200px', margin: '0 auto', padding: '20px', minHeight: '100vh' },
  hub: { textAlign: 'center' },
  header: { marginBottom: '40px', marginTop: '20px' },
  brand: { fontSize: '32px', fontWeight: 'bold', marginBottom: '8px' },
  subtitle: { fontSize: '14px', color: '#999', letterSpacing: '0.1em' },
  unitsGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '16px' },
  unitCard: { background: '#1a1a2e', border: '2px solid #9D4EDD', borderRadius: '12px', padding: '20px', cursor: 'pointer', textAlign: 'left', transition: 'all 0.2s' },
  unitCode: { fontSize: '12px', color: '#9D4EDD', fontWeight: 'bold', textTransform: 'uppercase', marginBottom: '4px' },
  unitName: { fontSize: '18px', fontWeight: 'bold', marginBottom: '8px' },
  unitBlurb: { fontSize: '13px', color: '#aaa', marginBottom: '12px' },
  unitProgress: { fontSize: '12px', color: '#FFB703', paddingTop: '8px', borderTop: '1px solid #333' },
  session: { maxWidth: '800px', margin: '0 auto' },
  backBtn: { background: '#333', border: 'none', color: '#fff', padding: '10px 20px', borderRadius: '8px', cursor: 'pointer', marginBottom: '20px', fontSize: '14px' },
  sessionHeader: { marginBottom: '30px', textAlign: 'center' },
  lessonTitle: { fontSize: '24px', fontWeight: 'bold', marginTop: '8px' },
  qContainer: { background: '#1a1a2e', border: '1px solid #333', borderRadius: '12px', padding: '30px' },
  qtext: { fontSize: '18px', fontWeight: '600', marginBottom: '20px', lineHeight: '1.5' },
  options: { display: 'flex', flexDirection: 'column', gap: '10px', marginBottom: '20px' },
  option: { padding: '14px', background: '#333', border: '1px solid #555', borderRadius: '8px', color: '#fff', cursor: 'pointer', textAlign: 'left', fontSize: '15px', transition: 'all 0.2s' },
  answerBox: { background: '#2a2a3e', padding: '16px', borderRadius: '8px', marginBottom: '20px', borderLeft: '4px solid #39FF14' },
  answerLabel: { fontSize: '12px', color: '#999', fontWeight: 'bold', marginBottom: '6px', textTransform: 'uppercase' },
  answerText: { fontSize: '15px', lineHeight: '1.6' },
  examBox: { background: '#2a2a3e', padding: '20px', borderRadius: '8px', marginBottom: '20px', borderLeft: '4px solid #FFB703' },
  examMarks: { fontSize: '12px', color: '#FFB703', fontWeight: 'bold', marginBottom: '12px' },
  schemeLabel: { fontSize: '12px', color: '#999', fontWeight: 'bold', marginBottom: '8px', textTransform: 'uppercase' },
  schemeList: { marginLeft: '20px', marginBottom: '16px', lineHeight: '1.7', fontSize: '14px' },
  modelLabel: { fontSize: '12px', color: '#999', fontWeight: 'bold', marginBottom: '8px', textTransform: 'uppercase', marginTop: '16px' },
  modelText: { fontSize: '15px', lineHeight: '1.6', color: '#e0e0e0' },
  tipBox: { background: '#2a2a3e', padding: '16px', borderRadius: '8px', marginTop: '20px', fontSize: '14px', lineHeight: '1.6', borderLeft: '4px solid #00D9FF' },
};

// Render the app
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(React.createElement(App));
